<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Categories')); ?> | <a href="<?php echo e(route('categories.create')); ?>"
                style="color: rgb(7, 109, 149); font-size: 20px; font-weight: bold;"> Add New</a>
        </h2>


     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">

                <div class="p-6 text-gray-900">

                    <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
                        <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400">
                            <thead
                                class="text-xs text-gray-700 uppercase bg-gray-50 white:bg-gray-700 white:text-gray-400">
                                <tr>
                                    <th scope="col" class="px-6 py-3">
                                        id
                                    </th>
                                    <th scope="col" class="px-6 py-3">
                                        name
                                    </th>
                                    <th scope="col" class="px-6 py-3">
                                        description
                                    </th>
                                    <th scope="col" class="px-6 py-3">
                                        image
                                    </th>
                                    <th scope="col" class="px-6 py-3">
                                       Actions
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="bg-white border-b white:bg-gray-900 white:border-gray-700">
                                    <th scope="row"
                                        class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap white:text-dark">
                                        <?php echo e($data->id); ?>

                                    </th>
                                    <td class="px-6 py-4 font-medium text-gray-900  white:text-dark">
                                        <?php echo e($data->name); ?>

                                    </td>
                                    <td class="px-6 py-4 font-medium text-gray-900  white:text-dark">
                                        <?php echo e($data->description); ?>

                                    </td>
                                    <td class="px-6 py-4 font-medium text-gray-900  white:text-dark">
                                        <img src="<?php echo e(Storage::url($data->image)); ?>" class="w-16 h-16 rounded" style="object-fit:cover">
                                       
                                    </td>
                                   
                                        <td
                                        class="py-4 px-6 text-sm font-medium text-white whitespace-nowrap white:text-white">
                                        <div class="flex space-x-2">
                                            <a href="<?php echo e(route('categories.edit', $data->id)); ?>"
                                                class="px-4 py-2 bg-green-500 hover:bg-green-700 rounded-lg  "><i class="bi bi-pencil-square"></i></a>
                                            <form
                                                class="px-4 py-2 bg-red-500 hover:bg-red-700 rounded-lg "
                                                method="POST"
                                                action="<?php echo e(route('categories.destroy', $data->id)); ?>"
                                                onsubmit="return confirm('Are you sure?');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit"><i class="bi bi-trash3-fill "></i></button>
                                            </form>
                                        </div>
                                    </td>
                                   
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>
<?php /**PATH C:\Users\WALTON\Desktop\laravel\project1\app\resources\views/categories/index.blade.php ENDPATH**/ ?>