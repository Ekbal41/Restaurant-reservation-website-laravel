

<!-- Uploaded to: SVG Repo, www.svgrepo.com, Generator: SVG Repo Mixer Tools -->
<svg width="50px" height="50px" viewBox="0 0 128 128" id="Layer_1" version="1.1" xml:space="preserve" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">

<style type="text/css">
	.st0{fill:#581166;}
	.st1{fill:#E83A3A;}
	.st2{fill:#FF5855;}
	.st3{opacity:0.5;}
	.st4{fill:#FFDA8E;}
	.st5{fill:#FFFFFF;}
	.st6{fill:#EABA65;}
	.st7{fill:#E6E6E6;}
	.st8{fill:#460A54;}
	.st9{fill:none;}
	.st10{fill:none;stroke:#581166;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:10;}
	.st11{fill:#F2F2F2;}
</style>

<g>

<g>

<g>

<g>

<path class="st4" d="M66.8,48.6h-4c-1.3,0-2.3-1-2.3-2.3V33c0-1.3,1-2.3,2.3-2.3h4c1.3,0,2.3,1,2.3,2.3v13.3      C69.2,47.5,68.1,48.6,66.8,48.6z"/>

</g>

</g>

</g>

<g>

<g>

<g>

<path class="st0" d="M64.8,50.5c-3.4,0-6.2-2.8-6.2-6.2V35c0-3.4,2.8-6.2,6.2-6.2c3.4,0,6.2,2.8,6.2,6.2v9.2      C71,47.7,68.2,50.5,64.8,50.5z M64.8,32.5c-1.4,0-2.5,1.1-2.5,2.5v9.2c0,1.4,1.1,2.5,2.5,2.5s2.5-1.1,2.5-2.5V35      C67.3,33.7,66.2,32.5,64.8,32.5z"/>

</g>

</g>

</g>

<g>

<g>

<g>

<path class="st2" d="M62.9,38.4c-26.4,0-47.8,21.4-47.8,47.8h95.5C110.6,59.8,89.3,38.4,62.9,38.4z"/>

</g>

</g>

</g>

<g>

<g>

<g>

<path class="st0" d="M110.6,88H15.1c-1,0-1.9-0.8-1.9-1.9c0-27.4,22.3-49.6,49.6-49.6s49.6,22.3,49.6,49.6      C112.5,87.2,111.7,88,110.6,88z M17,84.3h91.7c-1-24.4-21.2-44-45.9-44S18,59.9,17,84.3z"/>

</g>

</g>

</g>

<g>

<g>

<g>

<path class="st0" d="M122.1,88H7.6C6.7,88,6,87.2,6,86.2c0-1,0.7-1.9,1.6-1.9h114.5c0.9,0,1.6,0.8,1.6,1.9      C123.7,87.2,122.9,88,122.1,88z"/>

</g>

</g>

</g>

<g>

<g>

<g>

<path class="st11" d="M97.8,66.5c-0.8,0-1.5-0.5-1.8-1.3c-3.1-9.1-9.4-10.5-9.6-10.6c-1-0.2-1.7-1.2-1.4-2.2      c0.2-1,1.2-1.6,2.2-1.5c0.3,0.1,8.6,1.9,12.4,13.1c0.3,1-0.2,2-1.2,2.4C98.2,66.5,98,66.5,97.8,66.5z"/>

</g>

</g>

</g>

</g>

</svg><?php /**PATH C:\Users\WALTON\Desktop\laravel\project1\app\resources\views/components/application-logo.blade.php ENDPATH**/ ?>